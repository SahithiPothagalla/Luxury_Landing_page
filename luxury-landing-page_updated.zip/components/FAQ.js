import { useState } from 'react';

const FAQItem = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border-b border-gray-300 py-4">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full text-left text-lg font-semibold flex justify-between items-center"
      >
        {question}
        <span>{isOpen ? '-' : '+'}</span>
      </button>
      <div
        className={`overflow-hidden transition-all duration-500 ease-in-out ${
          isOpen ? 'max-h-40 opacity-100 mt-2' : 'max-h-0 opacity-0'
        }`}
      >
        <p className="text-gray-600 text-sm">{answer}</p>
      </div>
    </div>
  );
};

export default function FAQ() {
  const faqList = [
    { question: 'What is this site about?', answer: 'A premium landing page experience with animations.' },
    { question: 'Is it mobile-friendly?', answer: 'Absolutely. It is responsive across all devices.' },
    { question: 'Which technologies are used?', answer: 'Next.js, Tailwind CSS, and GSAP for animation.' },
  ];

  return (
    <section className="max-w-2xl mx-auto my-12 px-4">
      <h2 className="text-2xl font-bold mb-6">FAQs</h2>
      {faqList.map((faq, idx) => (
        <FAQItem key={idx} {...faq} />
      ))}
    </section>
  );
}