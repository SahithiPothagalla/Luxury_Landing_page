import { useEffect, useRef } from 'react';
import gsap from 'gsap';

export default function Home() {
  const headingRef = useRef(null);
  const paragraphRef = useRef(null);

  useEffect(() => {
    gsap.from(headingRef.current, { opacity: 0, y: -50, duration: 1.5 });
    gsap.from(paragraphRef.current.split(" ").map((_, i) => `#word-${i}`), {
      opacity: 0,
      stagger: 0.1,
      duration: 0.8,
      ease: "power2.out"
    });
  }, []);

  const firstPara = "This is a luxury landing page crafted with premium animations.";
  const splitWords = firstPara.split(" ");

  return (
    <main className="min-h-screen p-6 bg-white text-gray-900">
      <section className="max-w-4xl mx-auto">
        <h1 ref={headingRef} className="text-4xl font-bold mb-6">Welcome to Elegance</h1>
        <p ref={paragraphRef} className="text-lg leading-relaxed">
          {splitWords.map((word, i) => (
            <span key={i} id={`word-${i}`} className="inline-block mr-1 opacity-0">
              {word}
            </span>
          ))}
        </p>
      </section>
    </main>
  )
}

import FAQ from "@/components/FAQ";
import ProductSlider from "@/components/ProductSlider";

export default function HomePage() {
  return (
    <>
      <Home />
      <ProductSlider />
      <FAQ />
    </>
  );
}
